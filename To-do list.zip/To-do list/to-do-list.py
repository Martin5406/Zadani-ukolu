class SeznamUkolu:
    def __init__(self):
        self.ukoly = []

    def pridej_ukol(self, ukol):
        self.ukoly.append(ukol)

    def oznac_ukol_jako_hotovy(self, index_ukolu):
        if 0 <= index_ukolu < len(self.ukoly):
            self.ukoly[index_ukolu]['hotovo'] = True

    def odstran_ukol(self, index_ukolu):
        if 0 <= index_ukolu < len(self.ukoly):
            del self.ukoly[index_ukolu]

    def zobraz_ukoly(self):
        if self.ukoly:
            for index, ukol in enumerate(self.ukoly):
                status = "Hotový" if ukol['hotovo'] else "Nedokončený"
                print(f"{index + 1}. {ukol['popis']} - {status}")
        else:
            print("Žádné úkoly.")

def main():
    seznam_ukolu = SeznamUkolu()

    while True:
        print("\n1. Přidat úkol")
        print("2. Oznáčit úkol jako hotový")
        print("3. Odstranit úkol")
        print("4. Zobrazit úkoly")
        print("5. Ukončit")

        volba = input("Zadejte svůj výběr: ")

        if volba == '1':
            popis_ukolu = input("Zadejte popis úkolu: ")
            seznam_ukolu.pridej_ukol({'popis': popis_ukolu, 'hotovo': False})
        elif volba == '2':
            index_ukolu = int(input("Zadejte index úkolu k označení jako hotového: ")) - 1
            seznam_ukolu.oznac_ukol_jako_hotovy(index_ukolu)
        elif volba == '3':
            index_ukolu = int(input("Zadejte index úkolu k odstranění: ")) - 1
            seznam_ukolu.odstran_ukol(index_ukolu)
        elif volba == '4':
            seznam_ukolu.zobraz_ukoly()
        elif volba == '5':
            print("Ukončuji...")
            break
        else:
            print("Neplatný výběr. Zkuste to znovu.")

main()
