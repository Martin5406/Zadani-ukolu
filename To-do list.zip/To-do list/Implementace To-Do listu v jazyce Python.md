#### Úkol:

Vytvořte aplikaci To-Do listu v jazyce Python. Aplikace by měla umožňovat uživateli přidávat, odstraňovat a označovat úkoly jako hotové.

#### Podmínky zadání:

1. Aplikace musí být napsána v jazyce Python.
2. Použijte vhodné datové struktury pro ukládání seznamu úkolů.
3. Umožněte uživateli přidávat nové úkoly, označovat úkoly jako hotové a odstraňovat úkoly.
4. Aplikace by měla být uživatelsky přívětivá a poskytovat jasný uživatelský vstup a výstup.

#### Postup:

1. Navrhněte datovou strukturu pro ukládání seznamu úkolů.
2. Implementujte funkce pro přidávání, označování jako hotové a odstraňování úkolů.
3. Vytvořte uživatelské rozhraní, které umožní uživateli interagovat s aplikací.
4. Otestujte aplikaci s různými scénáři a ujistěte se, že všechny funkce fungují správně.

#### Výstup:

Odevzdejte kompletní kód vaší aplikace v repozitáři na GitHubu spolu s README souborem obsahujícím instrukce pro spuštění aplikace a používání jejích funkcí.

#### Inspirace:

Pro inspiraci můžete použít vzorový kód, který poskytuje příklad implementace To-Do listu v jazyce Python.


```python
class SeznamUkolu:
    def __init__(self):
        self.ukoly = []

    def pridej_ukol(self, ukol):
        self.ukoly.append(ukol)

    def oznac_ukol_jako_hotovy(self, index_ukolu):
        if 0 <= index_ukolu < len(self.ukoly):
            self.ukoly[index_ukolu]['hotovo'] = True

    def odstran_ukol(self, index_ukolu):
        if 0 <= index_ukolu < len(self.ukoly):
            del self.ukoly[index_ukolu]

    def zobraz_ukoly(self):
        if self.ukoly:
            for index, ukol in enumerate(self.ukoly):
                status = "Hotový" if ukol['hotovo'] else "Nedokončený"
                print(f"{index + 1}. {ukol['popis']} - {status}")
        else:
            print("Žádné úkoly.")

def main():
    seznam_ukolu = SeznamUkolu()

    while True:
        print("\n1. Přidat úkol")
        print("2. Oznáčit úkol jako hotový")
        print("3. Odstranit úkol")
        print("4. Zobrazit úkoly")
        print("5. Ukončit")

        volba = input("Zadejte svůj výběr: ")

        if volba == '1':
            popis_ukolu = input("Zadejte popis úkolu: ")
            seznam_ukolu.pridej_ukol({'popis': popis_ukolu, 'hotovo': False})
        elif volba == '2':
            index_ukolu = int(input("Zadejte index úkolu k označení jako hotového: ")) - 1
            seznam_ukolu.oznac_ukol_jako_hotovy(index_ukolu)
        elif volba == '3':
            index_ukolu = int(input("Zadejte index úkolu k odstranění: ")) - 1
            seznam_ukolu.odstran_ukol(index_ukolu)
        elif volba == '4':
            seznam_ukolu.zobraz_ukoly()
        elif volba == '5':
            print("Ukončuji...")
            break
        else:
            print("Neplatný výběr. Zkuste to znovu.")

main()
```

